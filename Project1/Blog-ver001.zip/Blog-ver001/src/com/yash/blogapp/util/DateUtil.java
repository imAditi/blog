package com.yash.blogapp.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	public String convertDatetoString(SimpleDateFormat formatter, Date today) {
		return formatter.format(today);
	}
	
	public String convert(SimpleDateFormat formatter,Date today) {
		
		return null;
	}

}
